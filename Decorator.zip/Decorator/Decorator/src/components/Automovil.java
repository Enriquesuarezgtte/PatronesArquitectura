package components;
//Componente Concreto 

import decoratorpattern.VentaAuto;

public abstract class Automovil implements VentaAuto {

}

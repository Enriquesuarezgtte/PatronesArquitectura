/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package components;

public class ChevroletSprint extends Automovil {
	// Metodos de la clase retorna un String
	@Override
	public String getDescription() {
		return "Chevrolet Sprint , Modelo 2019, Color azul turquesa";
	}

	// Metodos de la clase retorna un Int
	@Override
	public double getPrice() {
		return 80000000;
	}
}
